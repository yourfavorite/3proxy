#define VERSION "3proxy-0.8.8"
#define BUILDDATE "161213011647"
